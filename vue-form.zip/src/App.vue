<script setup lang="ts">
import {ref} from "vue"
import CustomInput from "./components/CustomInput.vue"
import {validateForm} from "@/lib/validations.ts"
import type {Errors} from "@/lib/validations.model"

const name = ref("")
const surname = ref("")
const email = ref("")
const phone = ref("")
const message = ref("")
const terms = ref(false)
const errors: Errors = ref({})

function resetForm(): void {
  name.value = ""
  surname.value = ""
  email.value = ""
  phone.value = ""
  message.value = ""
  terms.value = false
  errors.value = {}
}

function submitForm(): void {
  const resultValidation = validateForm(
      name.value,
      surname.value,
      email.value,
      phone.value,
      message.value,
      terms.value,
  )

  if (resultValidation.result) {
    alert("Form sent!")
    resetForm()
  } else {
    errors.value = resultValidation.errors
  }

}
</script>

<template>
  <h1>Contact form</h1>
  <p>Fill out the form below to contact us.</p>
  <form class="form" @submit.prevent>
    <div class="form__row">
      <CustomInput
          placeholder="Name"
          v-model="name"
          :error="errors.name"
      />
      <CustomInput
          placeholder="Surname"
          v-model="surname"
          :error="errors.surname"
      />
    </div>
    <div class="form__row">
      <CustomInput
          type="email"
          placeholder="e-mail"
          v-model="email"
          :error="errors.email"
      />
      <CustomInput
          type="tel"
          placeholder="12345678"
          v-model="phone"
          :error="errors.phone"
      />
    </div>
    <div>
      <textarea maxlength="200" placeholder="Write a message." v-model="message" required />
      <p v-if="errors.message" class="error-message">{{ errors.message }}</p>
    </div>
    <div class="form__terms">
      <label>
        <input type="checkbox" v-model="terms">
        I agree to Terms and conditions and Privacy Policy
      </label>
      <p v-if="errors.terms" class="error-message">{{ errors.terms }}</p>
    </div>
    <button type="submit" @click.prevent="submitForm">Send</button>
  </form>
</template>